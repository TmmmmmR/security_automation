#!/usr/bin/env groovy
def call(Closure configBlock) {
    def config= [:]
    configBlock.resolveStrategy = Closure.DELEGATE_FIRST
    configBlock.delegate = config
    configBlock()
    def uniqId = UUID.randomUUID().toString()

JobProperties{
    days_to_keep            = "30"
    num_to_keep             = "30"
    upstream_project        = null
    allow_concurrent_builds = false
    optimize_performance    = true
}
podTemplate(
    label: "jnlpslave-checkmarx-${config.project_name}",
    containers: [
        containerTemplate(
            name: 'jnlp',
            image: 'registry-docker.intramundi.com/amundi/jenkins-slave:3.27.2',
            ttyEnabled: true,
            privileged: true,
            envVars: [
            containerEnvVar(
                key: 'HOME',
                value: '/home/jenkins/'
                ),
            ]
        ),
        containerTemplate(
            name: 'checkmarx',
            image: 'registry-docker.intramundi.com/amundi/checkmarx-cxcli-py',
            ttyEnabled: true,
            alwaysPullImage: true
            ]
        )
    ],
    volumes: [
        configMapVolume(
            mountPath: "/etc/docker/certs.d/registry-docker.intramundi.com/",
            configMapName: "ca-bundle"
        )
    ],
    imagePullSecrets: [ "artifactory-secret" ],
) {
    node("jnlpslave-checkmarx-${config.project_name}"){
        try {
            stage('Checkout') {
                checkout scm
            }
            stage('Checkmarx Analysis') {
                container('checkmarx'){
                    withCredentials([
                        usernamePassword(
                            usernameVariable: 'CHECKMARX_USER',
                            passwordVariable: 'CHECKMARX_PASSWORD',
                            credentialsId: config.secret_id ?: 'checkmarx'
                            )
                        ]) {
                        def current_path           = sh(returnStdout: true, script: "pwd")
                        def checkmarx_url          = "https://sast.sopra.partenaires.group.gca/"

                        echo "Project Id          : ${config.project_id}"
                        echo "User                : $CHECKMARX_USER"
                        echo "password            : $CHECKMARX_PASSWORD"
                        echo "Checkmarx url       : ${checkmarx_url}"
                        echo "location path       : ${current_path}"

                        sh "python ScanProject.py --project ${config.project_id} --source ${current_path}/${config.git_repo} --report report.xml --url ${checkmarx_url} --username $CHECKMARX_USER --password $CHECKMARX_PASSWORD"
                    }
                }
            }
        }
        catch(Exception e) {
            println "error message : ${e}"
            currentBuild.result = 'FAILURE'
            throw e
        }
        finally {
            Notification{
                notification_to = config.notification_to ?: false
            }
        }
    }
}
}
